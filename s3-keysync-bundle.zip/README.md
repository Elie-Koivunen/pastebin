# isi_s3_setkey
A tool to set a S3 Secret Key to a custom value

This tool is intended to be used on PowerScale Clusters running OneFS 9.5 and later commandline. It provides an alternative to "isi s3 keys create" with similar functionality except that it does not create a random secret key. This allows administrators to configure the same accessid with the identical secret key on multiple clusters to allow DR and Failover.<br>

The tool requires SSH access as well as the following RBAC privileges:
- `ISI_PRIV_S3_MYKEYS`
- `ISI_PRIV_AUTH`

A secret key must be at least 8 characters long and must not exceed 28 characters!

By default isi_s3_setkey detects the current user and access zone and sets custom Secret key.
```
        # isi_s3_setkey -s
        SecretKey:
        Verifying - SecretKey:
        Access ID: 1_root_accid
        Secret Key: TEST-Secret-1234
        Timestamp: 28-11-2024 17:19:47

```
The new secret can also be received thru PIPE:

```
        # echo TEST-Secret-1234 | ./isi_s3_setkey -s
        Access ID: 1_root_accid
        Secret Key: TEST-Secret-1234
        Timestamp: 28-11-2024 17:19:47
```

Output can be surpressed by removing the "-s" argument or switched to JSON format:

```
        # echo TEST-Secret-1234 | ./isi_s3_setkey -s -j 

        {
                "access_id" : "1_root_accid",
                "secret_key" : "TEST-Secret-1234",
                "secret_key_timestamp" : 1654524315
        }
```

Keys for different users can be set via the option -z [Zone ID] and -u [username]:
```
        # echo TEST-Secret-1234 | ./isi_s3_setkey -s -j -z 1 -u stephan

        {
                "access_id" : "1_stephan_accid",
                "secret_key" : "TEST-Secret-1234",
                "secret_key_timestamp" : 1654524222
        }
```

If an access ID for a given user exists the Secret Key is updated by the tool.
```
        # echo TEST-Secret-5678 | ./isi_s3_setkey -s -j -u stephan 
        Update existing AccessID "1_stephan_accid"? (y/n): y

        {
                "access_id" : "1_stephan_accid",
                "old_key_expiry" : 1654525032,
                "old_key_timestamp" : 1654524222,
                "secret_key" : "TEST-Secret-5678",
                "secret_key_timestamp" : 1654524432
        }
```
While updating an existing accessid the new secret must differ from the last value.

---
### Usage:
```
isi_s3_setkey: At least one argument must be provided!

Set or update an S3 ID and Key pair with a custom Secret Key.

USAGE: isi_s3_setkey [-z zid] [-u username] [secret]

        -z <Zone ID>    Specify the zone id number for the AccessID. [Default: current zone]
        -u <username>   Create or update this users S3 keys. [Default: current user]
        -j              Json: Output the S3 Keys in json format.
        -s              show S3 keys.
        -t              old key retention in minutes [Default: 10, Max: 1440]
        -f              force overwrite of existing keys and avoid interactive prompts!

        [secret]        New secret key [min:8 - max:28 charaters] (Deprecated: For backwards compatibility only!)

TIPP:
        If NO secret key is provided, then the program will prompt for one.
        For use in automation or scripts it is recommended to read in the new secret key via PIPE.
        Also it is recommended to leverage -f to avoid any prompts.

EXAMPLE:
        # echo very secret key | ./isi_s3_setkey -s -f -u username

```
---
## How to install the tool
1. Download installer code to /ifs/data/Isilon_Support of any Node in a Cluster
2. run the script to install it only to the current Node:
```
# python /ifs/data/Isilon_Support/installer.py
```
3. to install on all Nodes wrap it in isi_for_array:
```
  # isi_for_array -s python /ifs/data/Isilon_Support/installer.py
```
4. the script will select the correct binary based on the installed OneFS version, 
   and avoid installation on untested or unsupported versions.
5. There will be no output if the tool completes successfully.
   the result will be logged in "/ifs/data/Isilon_Support/install_s3key_setter.log"

## Support Notice:
Support for OneFS 9.4 and earlier has been dropped, in a way that these tool builds will not receive further updates. <br> The binaries however will remain available in the provided package.
